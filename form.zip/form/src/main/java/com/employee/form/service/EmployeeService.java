package com.employee.form.service;

import java.util.List;

import com.employee.form.model.Employee;

public interface EmployeeService {

	 public Employee createEmployee(Employee employee);
	 
	 public List<Employee> getAllEmployees();
	 
	 public Employee getEmployeeById(Long id);
}
