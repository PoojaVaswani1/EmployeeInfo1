package com.employee.form.model;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String baseLocation;
    private boolean reportingToBaseLocation;
    private String explanation;
    private String certifications;
    private String benchStatus;
    private String benchCalls;
    private String currentWork;
    private boolean trainingOrActivity;
    private String otherActivities;
   
    private int interviewPreparedness;
    private boolean digiDashboard;
    private boolean previousProject;
    private String projectName;
    private String role;
    
    private String projectManagerName;
    private String projectManagerEmail;
    private String releaseReason;
    private String technologiesWorkedOn;
    private String comments;
    
    // getter setter
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBaseLocation() {
		return baseLocation;
	}
	public void setBaseLocation(String baseLocation) {
		this.baseLocation = baseLocation;
	}
	public boolean isReportingToBaseLocation() {
		return reportingToBaseLocation;
	}
	public void setReportingToBaseLocation(boolean reportingToBaseLocation) {
		this.reportingToBaseLocation = reportingToBaseLocation;
	}
	public String getExplanation() {
		return explanation;
	}
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}
	public String getCertifications() {
		return certifications;
	}
	public void setCertifications(String certifications) {
		this.certifications = certifications;
	}
	public String getBenchStatus() {
		return benchStatus;
	}
	public void setBenchStatus(String benchStatus) {
		this.benchStatus = benchStatus;
	}
	public String getBenchCalls() {
		return benchCalls;
	}
	public void setBenchCalls(String benchCalls) {
		this.benchCalls = benchCalls;
	}
	public String getCurrentWork() {
		return currentWork;
	}
	public void setCurrentWork(String currentWork) {
		this.currentWork = currentWork;
	}
	public boolean isTrainingOrActivity() {
		return trainingOrActivity;
	}
	public void setTrainingOrActivity(boolean trainingOrActivity) {
		this.trainingOrActivity = trainingOrActivity;
	}
	public String getOtherActivities() {
		return otherActivities;
	}
	public void setOtherActivities(String otherActivities) {
		this.otherActivities = otherActivities;
	}
	
	public int getInterviewPreparedness() {
		return interviewPreparedness;
	}
	public void setInterviewPreparedness(int interviewPreparedness) {
		this.interviewPreparedness = interviewPreparedness;
	}
	public boolean isDigiDashboard() {
		return digiDashboard;
	}
	public void setDigiDashboard(boolean digiDashboard) {
		this.digiDashboard = digiDashboard;
	}
	public boolean isPreviousProject() {
		return previousProject;
	}
	public void setPreviousProject(boolean previousProject) {
		this.previousProject = previousProject;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	public String getProjectManagerName() {
		return projectManagerName;
	}
	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}
	public String getProjectManagerEmail() {
		return projectManagerEmail;
	}
	public void setProjectManagerEmail(String projectManagerEmail) {
		this.projectManagerEmail = projectManagerEmail;
	}
	public String getReleaseReason() {
		return releaseReason;
	}
	public void setReleaseReason(String releaseReason) {
		this.releaseReason = releaseReason;
	}
	public String getTechnologiesWorkedOn() {
		return technologiesWorkedOn;
	}
	public void setTechnologiesWorkedOn(String technologiesWorkedOn) {
		this.technologiesWorkedOn = technologiesWorkedOn;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	public Employee(Long id, String name, String email, String baseLocation, boolean reportingToBaseLocation,
			String explanation, String certifications, String benchStatus, String benchCalls, String currentWork,
			boolean trainingOrActivity, String otherActivities, 
			int interviewPreparedness, boolean digiDashboard, boolean previousProject, String projectName, String role,
			 String projectManagerName, String projectManagerEmail,
			String releaseReason, String technologiesWorkedOn, String comments) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.baseLocation = baseLocation;
		this.reportingToBaseLocation = reportingToBaseLocation;
		this.explanation = explanation;
		this.certifications = certifications;
		this.benchStatus = benchStatus;
		this.benchCalls = benchCalls;
		this.currentWork = currentWork;
		this.trainingOrActivity = trainingOrActivity;
		this.otherActivities = otherActivities;
		//this.activityCompletionDate = activityCompletionDate;
		this.interviewPreparedness = interviewPreparedness;
		this.digiDashboard = digiDashboard;
		this.previousProject = previousProject;
		this.projectName = projectName;
		this.role = role;
		//this.taggingStartDate = taggingStartDate;
		//this.taggingEndDate = taggingEndDate;
		this.projectManagerName = projectManagerName;
		this.projectManagerEmail = projectManagerEmail;
		this.releaseReason = releaseReason;
		this.technologiesWorkedOn = technologiesWorkedOn;
		this.comments = comments;
	}

   
	
    
}

