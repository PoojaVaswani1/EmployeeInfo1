package com.employee.form.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.form.model.Employee;
import com.employee.form.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl {
	
	 @Autowired
	  public  EmployeeRepo employeeRepository;

	    public Employee createEmployee(Employee employee) {
	        // Implement any business logic before saving the employee
	        return employeeRepository.save(employee);
	    }

	    public List<Employee> getAllEmployees() {
	        return employeeRepository.findAll();
	    }

	    // Implement other service methods for CRUD operations and additional business logic as needed

	    // For example, if you want to implement a method to retrieve an employee by ID:
	    public Employee getEmployeeById(Long id) {
	        return employeeRepository.findById(id).orElse(null);
	    }
	}
	






